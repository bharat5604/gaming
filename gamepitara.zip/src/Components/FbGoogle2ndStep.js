import React from 'react'

const FbGoogle2ndStep = (props) => {
    return (
        <div className="fb2nd" id={props.openFb}>
            <div className="header">
                <h3>bharat</h3>
            </div>
        </div>
    )
}

export default FbGoogle2ndStep
