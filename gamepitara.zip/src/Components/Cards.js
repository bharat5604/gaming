import React from 'react'
import Header from './Header';
import banner from './Assets/img/banner.jpg'
import {Link} from 'react-router-dom';
import GameProvider from './GameProvider';
import Footer from './Footer';
import Testimonial from './Testimonial';
import blackjack from './Assets/img/icons/blackjack.png'
import baccarat from './Assets/img/icons/baccarat.png'
import teenpati from './Assets/img/icons/poker.png'
import andarbahar from './Assets/img/icons/cards.png'
import casino from './Assets/img/icons/casinowar.png'
import casinoHoldem from './Assets/img/icons/holdem.png'
import blackJ from './Assets/img/games/blackj.jpg'
import speedy from './Assets/img/games/speedy.jpg'
import blackjack1 from './Assets/img/games/unlimited21.jpg'
import blackjack2 from './Assets/img/games/blackjack2.jpg'
import blackjack3 from './Assets/img/games/blackjack3.jpg'
import blackjack4 from './Assets/img/games/blackjack4.jpg'
import blackjack5 from './Assets/img/games/blackjack5.jpg'
import blackjack6 from './Assets/img/games/blackjack6.jpg'
import blackjack7 from './Assets/img/games/blackjack7.jpg'
import blackjack8 from './Assets/img/games/blackjack8.jpg'
import blackjack9 from './Assets/img/games/blackjack9.jpg'
import blackjack10 from './Assets/img/games/blackjack10.jpg'
import blackjack11 from './Assets/img/games/blackjack11.jpg'
import blackjack12 from './Assets/img/games/blackjack12.jpg'

const Cards = () => {
    return (
        <div className="cards">
            <Header />
            <div className="card__banner">
                <img src={banner} className="img-fluid" alt=""/>
                <div className="container">
                    <div className="abs">
                        <h3>PLAY MOST POPULAR</h3>
                        <span>card games available free here</span>
                    </div>
                </div>
            </div>

            {/* games part */}
            <div className="games__part">
                <div className="container">
                    <div className="row">
                        <div className="col-md-3">
                            <div className="in__games">
                                <ul>
                                    <li>
                                        <Link to="">
                                            <img src={blackjack} alt="black jack"/>
                                            Black Jack
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="">
                                            <img src={baccarat} alt="black jack"/>
                                            baccarat
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="">
                                            <img src={teenpati} alt="black jack"/>
                                            teen pati
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="">
                                            <img src={andarbahar} alt="black jack"/>
                                            andar bahar
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="">
                                            <img src={casino} alt="black jack"/>
                                            casino war
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="">
                                            <img src={casinoHoldem} alt="black jack"/>
                                            casino holde
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-md-9">
                            <div className="games_image">
                                <div className="row">
                                    <div className="col-md-4">
                                        <img src={blackJ} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-7">
                                        <img src={speedy} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack1} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack2} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack3} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack4} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack5} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack6} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack7} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack8} className="img-fluid" alt=""/>
                                    </div>

                                    <div className="col-md-3">
                                        <img src={blackjack9} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack10} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack11} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack12} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack10} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack11} className="img-fluid" alt=""/>
                                    </div>
                                    <div className="col-md-3">
                                        <img src={blackjack12} className="img-fluid" alt=""/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <GameProvider />
            <Testimonial />
            <Footer />
        </div>
    )
}

export default Cards
