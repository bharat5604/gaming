import sld1 from "./Assets/img/winning/sld1.png";
import sld2 from "./Assets/img/winning/sld2.png";
import sld3 from "./Assets/img/winning/sld3.png";
import sld4 from "./Assets/img/winning/sld4.png";
import sld5 from "./Assets/img/winning/sld5.png";
import sld6 from "./Assets/img/winning/sld6.png";
export const winnersData = [
  {
    winnerName: "reddy***",
    winnerImg: sld1,
    winnerGame: "lucky pandas",
    winnerPrice: "4,1200.00",
  },
  {
    winnerName: "shredder****",
    winnerImg: sld2,
    winnerGame: "lucky pandas",
    winnerPrice: "10,2200.00",
  },
  {
    winnerName: "shredder****",
    winnerImg: sld3,
    winnerGame: "lucky pandas",
    winnerPrice: "10,2200.00",
  },
  {
    winnerName: "shredder****",
    winnerImg: sld4,
    winnerGame: "lucky pandas",
    winnerPrice: "10,2200.00",
  },
  {
    winnerName: "shredder****",
    winnerImg: sld5,
    winnerGame: "lucky pandas",
    winnerPrice: "10,2200.00",
  },
  {
    winnerName: "shredder****",
    winnerImg: sld6,
    winnerGame: "lucky pandas",
    winnerPrice: "10,2200.00",
  },
];
